package com.alishaweb.app;

import android.app.Activity;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Insets;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.alishaweb.app.R.layout.activity_main);

        webView = findViewById(com.alishaweb.app.R.id.webview);

        // Android 15 (targetSdk 35) memakai edge-to-edge secara default.
        // Beri ruang sesuai status bar dan navigation bar supaya isi AlishaWeb
        // tidak berada di belakang ikon notifikasi atau tombol navigasi Android.
        webView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int topInset;
                int bottomInset;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Insets systemBars = insets.getInsets(WindowInsets.Type.systemBars());
                    topInset = systemBars.top;
                    bottomInset = systemBars.bottom;
                } else {
                    topInset = insets.getSystemWindowInsetTop();
                    bottomInset = insets.getSystemWindowInsetBottom();
                }

                v.setPadding(0, topInset, 0, bottomInset);
                return insets;
            }
        });
        webView.requestApplyInsets();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                }

                // Pastikan tombol gambar chat membuka pemilih gambar, bukan file umum.
                if (intent.getType() == null || "*/*".equals(intent.getType())) {
                    intent.setType("image/*");
                }
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Link eksternal (WhatsApp, Telegram, browser, dll.) harus keluar
                // dari WebView agar aplikasi tujuan bisa terbuka.
                if (scheme != null && scheme.equals("file")) {
                    return false;
                }

                if (scheme != null && (scheme.equals("http") || scheme.equals("https"))) {
                    String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";

                    // WhatsApp: paksa buka aplikasi WhatsApp lebih dulu.
                    if (host.equals("wa.me") || host.endsWith("whatsapp.com")) {
                        Intent waIntent = new Intent(Intent.ACTION_VIEW, uri);
                        waIntent.setPackage("com.whatsapp");
                        try {
                            startActivity(waIntent);
                            return true;
                        } catch (ActivityNotFoundException e) {
                            // Coba WhatsApp Business.
                            Intent wabIntent = new Intent(Intent.ACTION_VIEW, uri);
                            wabIntent.setPackage("com.whatsapp.w4b");
                            try {
                                startActivity(wabIntent);
                                return true;
                            } catch (ActivityNotFoundException e2) {
                                // Fallback ke aplikasi/browser yang tersedia.
                                try {
                                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                                    return true;
                                } catch (Exception ignored) {
                                    return false;
                                }
                            }
                        }
                    }

                    // Telegram: paksa buka aplikasi Telegram lebih dulu.
                    if (host.equals("t.me") || host.endsWith("telegram.me")) {
                        Intent tgIntent = new Intent(Intent.ACTION_VIEW, uri);
                        tgIntent.setPackage("org.telegram.messenger");
                        try {
                            startActivity(tgIntent);
                            return true;
                        } catch (ActivityNotFoundException e) {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                                return true;
                            } catch (Exception ignored) {
                                return false;
                            }
                        }
                    }

                    // Link web biasa tetap dibuka di WebView.
                    return false;
                }

                // Tangani redirect custom-scheme dari WhatsApp / Telegram.
                if (scheme != null && scheme.equals("whatsapp")) {
                    Intent wa = new Intent(Intent.ACTION_VIEW, uri);
                    wa.setPackage("com.whatsapp");
                    try {
                        startActivity(wa);
                        return true;
                    } catch (Exception e) {
                        Intent wab = new Intent(Intent.ACTION_VIEW, uri);
                        wab.setPackage("com.whatsapp.w4b");
                        try {
                            startActivity(wab);
                            return true;
                        } catch (Exception ignored) {
                            return true;
                        }
                    }
                }

                if (scheme != null && scheme.equals("tg")) {
                    Intent tg = new Intent(Intent.ACTION_VIEW, uri);
                    tg.setPackage("org.telegram.messenger");
                    try {
                        startActivity(tg);
                        return true;
                    } catch (Exception ignored) {
                        return true;
                    }
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme();

                    if ("tg".equals(scheme)) {
                        Intent tg = new Intent(Intent.ACTION_VIEW, uri);
                        tg.setPackage("org.telegram.messenger");
                        startActivity(tg);
                        return true;
                    }

                    if ("whatsapp".equals(scheme)) {
                        Intent wa = new Intent(Intent.ACTION_VIEW, uri);
                        try {
                            wa.setPackage("com.whatsapp");
                            startActivity(wa);
                        } catch (Exception e) {
                            Intent wab = new Intent(Intent.ACTION_VIEW, uri);
                            wab.setPackage("com.whatsapp.w4b");
                            startActivity(wab);
                        }
                        return true;
                    }

                    if ("http".equals(scheme) || "https".equals(scheme)) {
                        String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
                        if (host.equals("t.me") || host.endsWith("telegram.me") ||
                            host.equals("wa.me") || host.endsWith("whatsapp.com")) {
                            startActivity(new Intent(Intent.ACTION_VIEW, uri));
                            return true;
                        }
                        return false;
                    }
                } catch (Exception ignored) {}
                return false;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {}
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) {
            return;
        }

        Uri[] results = null;

        if (resultCode == Activity.RESULT_OK) {
            results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);

            // Fallback untuk beberapa galeri Android yang hanya mengembalikan data URI.
            if ((results == null || results.length == 0) && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    private void closeAppImmediately() {
        // Kosongkan frame WebView lebih dulu agar halaman terakhir tidak tertahan
        // beberapa saat saat Activity ditutup.
        if (webView != null) {
            webView.setVisibility(View.INVISIBLE);
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.clearCache(false);
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }

        finishAndRemoveTask();
        overridePendingTransition(0, 0);
    }

    @Override
    public void onBackPressed() {
        // Jika masih ada riwayat halaman internal, kembali seperti biasa.
        // Jika sudah di halaman utama, tutup aplikasi langsung tanpa animasi/frame tertinggal.
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            closeAppImmediately();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
