-- ============================================================
-- ALISHAWEB PANEL ADMIN V2 - STORAGE GAMBAR
-- Jalankan SEKALI di Supabase SQL Editor.
-- Membuat bucket public untuk Icon APK dan HERO.
-- Upload hanya boleh oleh akun admin.
-- ============================================================

insert into storage.buckets (id, name, public)
values ('alishaweb-media', 'alishaweb-media', true)
on conflict (id) do update set public = true;

drop policy if exists "alishaweb media public read" on storage.objects;
drop policy if exists "alishaweb media admin insert" on storage.objects;
drop policy if exists "alishaweb media admin update" on storage.objects;
drop policy if exists "alishaweb media admin delete" on storage.objects;

create policy "alishaweb media public read"
on storage.objects
for select
to public
using (bucket_id = 'alishaweb-media');

create policy "alishaweb media admin insert"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'alishaweb-media'
  and public.is_admin()
);

create policy "alishaweb media admin update"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'alishaweb-media'
  and public.is_admin()
)
with check (
  bucket_id = 'alishaweb-media'
  and public.is_admin()
);

create policy "alishaweb media admin delete"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'alishaweb-media'
  and public.is_admin()
);
