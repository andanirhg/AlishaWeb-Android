ALISHAWEB ANDROID

1. Buka folder ini dengan Android Studio.
2. Tunggu Gradle sync selesai.
3. Pilih Build > Build APK(s).
4. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Website AlishaWeb terbaru sudah ditanam sebagai app/src/main/assets/index.html.
Internet permission sudah aktif agar Supabase/link eksternal dapat bekerja.
