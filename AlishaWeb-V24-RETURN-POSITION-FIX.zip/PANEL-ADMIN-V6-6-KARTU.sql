-- ============================================================
-- ALISHAWEB PANEL ADMIN V6 - 6 KARTU TERBARU/REKOMENDASI
-- Jalankan SEKALI di Supabase SQL Editor.
-- ============================================================

create table if not exists public.recommendation_cards (
  id uuid primary key default gen_random_uuid(),
  position integer not null unique check (position between 1 and 6),
  name text not null,
  icon_url text not null,
  link_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.recommendation_cards enable row level security;

drop policy if exists "public read recommendation cards" on public.recommendation_cards;
drop policy if exists "admin insert recommendation cards" on public.recommendation_cards;
drop policy if exists "admin update recommendation cards" on public.recommendation_cards;
drop policy if exists "admin delete recommendation cards" on public.recommendation_cards;

create policy "public read recommendation cards"
on public.recommendation_cards
for select
to anon, authenticated
using (active = true or public.is_admin());

create policy "admin insert recommendation cards"
on public.recommendation_cards
for insert
to authenticated
with check (public.is_admin());

create policy "admin update recommendation cards"
on public.recommendation_cards
for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "admin delete recommendation cards"
on public.recommendation_cards
for delete
to authenticated
using (public.is_admin());

grant select on public.recommendation_cards to anon, authenticated;
grant insert, update, delete on public.recommendation_cards to authenticated;


insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (1,'XD880','https://res.cloudinary.com/m7amke5n/image/upload/v1787296658/urw34lck7cvmpmayuhu5.png','https://xd880.xyz?pid=63217797&fromPage=AGENT_ONE',true)
on conflict (position) do nothing;

insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (2,'W57','https://res.cloudinary.com/m7amke5n/image/upload/v1787296706/ld1mhl9cxthzsrwvfmoi.jpg','https://putridey.org/share/c2hhcmVDb2RlPTQ2NzA3NzI1OTA3MDAxMzQ0MA',true)
on conflict (position) do nothing;

insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (3,'T92','https://res.cloudinary.com/m7amke5n/image/upload/v1787296731/lazyc6xmeu40ivuiaqda.png','https://bk6xo.xyz/s/C024211431',true)
on conflict (position) do nothing;

insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (4,'777YK','https://res.cloudinary.com/m7amke5n/image/upload/v1787296753/vvipxnnt3gi6wdrzel9z.png','https://l9eu5mvh7u5.com/s/E8FDD10503',true)
on conflict (position) do nothing;

insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (5,'S61','https://res.cloudinary.com/m7amke5n/image/upload/v1787296774/mqy0zevnjgunbwsmurbf.jpg','https://orrint.vip/share/c2hhcmVDb2RlPTQ2NjY0NjEyMzAzMDExODQwMA',true)
on conflict (position) do nothing;

insert into public.recommendation_cards(position,name,icon_url,link_url,active)
values (6,'HELLO99','https://res.cloudinary.com/m7amke5n/image/upload/v1787296801/qer4cjcy4lekgu9zjckz.png','https://hello99.shop/?ref=HELLBPHWRZ',true)
on conflict (position) do nothing;
