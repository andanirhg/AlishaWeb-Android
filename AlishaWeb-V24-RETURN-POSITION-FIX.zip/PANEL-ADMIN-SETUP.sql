-- ============================================================
-- ALISHAWEB PANEL ADMIN - APK + HERO
-- Jalankan SEKALI di Supabase SQL Editor.
-- Fungsi public.is_admin() sudah dibuat sebelumnya.
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'LAINNYA',
  icon_url text,
  download_url text,
  developer text default '@alishaweb',
  description text,
  version text,
  size text,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.hero_banners (
  id uuid primary key default gen_random_uuid(),
  title text,
  image_url text not null,
  link_url text,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists apps_set_updated_at on public.apps;
create trigger apps_set_updated_at
before update on public.apps
for each row execute function public.set_updated_at();

drop trigger if exists hero_set_updated_at on public.hero_banners;
create trigger hero_set_updated_at
before update on public.hero_banners
for each row execute function public.set_updated_at();

alter table public.apps enable row level security;
alter table public.hero_banners enable row level security;

drop policy if exists "public read apps" on public.apps;
drop policy if exists "admin insert apps" on public.apps;
drop policy if exists "admin update apps" on public.apps;
drop policy if exists "admin delete apps" on public.apps;

create policy "public read apps"
on public.apps for select
to anon, authenticated
using (true);

create policy "admin insert apps"
on public.apps for insert
to authenticated
with check (public.is_admin());

create policy "admin update apps"
on public.apps for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "admin delete apps"
on public.apps for delete
to authenticated
using (public.is_admin());

drop policy if exists "public read hero" on public.hero_banners;
drop policy if exists "admin insert hero" on public.hero_banners;
drop policy if exists "admin update hero" on public.hero_banners;
drop policy if exists "admin delete hero" on public.hero_banners;

create policy "public read hero"
on public.hero_banners for select
to anon, authenticated
using (true);

create policy "admin insert hero"
on public.hero_banners for insert
to authenticated
with check (public.is_admin());

create policy "admin update hero"
on public.hero_banners for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "admin delete hero"
on public.hero_banners for delete
to authenticated
using (public.is_admin());

grant select on public.apps to anon, authenticated;
grant insert, update, delete on public.apps to authenticated;

grant select on public.hero_banners to anon, authenticated;
grant insert, update, delete on public.hero_banners to authenticated;
