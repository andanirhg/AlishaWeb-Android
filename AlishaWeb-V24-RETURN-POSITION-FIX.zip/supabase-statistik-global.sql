-- ============================================================
-- ALISHAWEB - STATISTIK GLOBAL OTOMATIS
-- Jalankan SEKALI di Supabase SQL Editor.
-- File ini menambah Visitor Hari Ini global.
-- app_stats + increment_app_view/download tetap dipakai seperti sebelumnya.
-- ============================================================

create table if not exists public.daily_visitors (
  visit_date date not null,
  visitor_key text not null,
  created_at timestamptz not null default now(),
  primary key (visit_date, visitor_key)
);

alter table public.daily_visitors enable row level security;

-- Tidak perlu membuka insert/select langsung ke publik.
-- Browser hanya memanggil RPC security definer di bawah.
create or replace function public.register_daily_visitor(
  p_visit_date date,
  p_visitor_key text
)
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
  total_visitors bigint;
begin
  insert into public.daily_visitors(visit_date, visitor_key)
  values(p_visit_date, p_visitor_key)
  on conflict (visit_date, visitor_key) do nothing;

  select count(*) into total_visitors
  from public.daily_visitors
  where visit_date = p_visit_date;

  return total_visitors;
end;
$$;

grant execute on function public.register_daily_visitor(date,text)
to anon, authenticated;

-- Pastikan fungsi statistik aplikasi sudah ada.
create table if not exists public.app_stats (
  app_id text primary key,
  views bigint not null default 0,
  downloads bigint not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.app_stats enable row level security;

drop policy if exists "public can read app stats" on public.app_stats;
create policy "public can read app stats"
on public.app_stats for select
to anon, authenticated
using (true);

drop policy if exists "public can create app stats" on public.app_stats;
create policy "public can create app stats"
on public.app_stats for insert
to anon, authenticated
with check (true);

create or replace function public.increment_app_view(p_app_id text)
returns public.app_stats
language plpgsql
security definer
set search_path = public
as $$
declare result public.app_stats;
begin
  insert into public.app_stats(app_id, views, downloads)
  values(p_app_id,1,0)
  on conflict(app_id) do update set
    views=public.app_stats.views+1,
    updated_at=now()
  returning * into result;
  return result;
end;
$$;

create or replace function public.increment_app_download(p_app_id text)
returns public.app_stats
language plpgsql
security definer
set search_path = public
as $$
declare result public.app_stats;
begin
  insert into public.app_stats(app_id, views, downloads)
  values(p_app_id,0,1)
  on conflict(app_id) do update set
    downloads=public.app_stats.downloads+1,
    updated_at=now()
  returning * into result;
  return result;
end;
$$;

grant execute on function public.increment_app_view(text) to anon, authenticated;
grant execute on function public.increment_app_download(text) to anon, authenticated;
