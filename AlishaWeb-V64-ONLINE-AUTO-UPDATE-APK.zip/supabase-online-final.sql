-- ============================================================
-- ALISHAWEB - SUPABASE FINAL: STATISTIK + VISITOR + CHAT ONLINE
-- Jalankan SEKALI di Supabase > SQL Editor > New query > Run
-- ============================================================

create extension if not exists pgcrypto;

-- -----------------------------
-- STATISTIK APLIKASI
-- -----------------------------
create table if not exists public.app_stats (
  app_id text primary key,
  views bigint not null default 0,
  downloads bigint not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.app_stats add column if not exists last_downloaded_at timestamptz;

alter table public.app_stats enable row level security;

drop policy if exists "public can read app stats" on public.app_stats;
create policy "public can read app stats"
on public.app_stats for select to anon, authenticated using (true);

drop policy if exists "public can create app stats" on public.app_stats;
create policy "public can create app stats"
on public.app_stats for insert to anon, authenticated with check (true);

grant select, insert on public.app_stats to anon, authenticated;

create or replace function public.increment_app_view(p_app_id text)
returns public.app_stats
language plpgsql security definer set search_path=public
as $$
declare r public.app_stats;
begin
  insert into public.app_stats(app_id,views,downloads) values(p_app_id,1,0)
  on conflict(app_id) do update set views=public.app_stats.views+1,updated_at=now()
  returning * into r;
  return r;
end; $$;

create or replace function public.increment_app_download(p_app_id text)
returns public.app_stats
language plpgsql security definer set search_path=public
as $$
declare r public.app_stats;
begin
  insert into public.app_stats(app_id,views,downloads,last_downloaded_at) values(p_app_id,0,1,now())
  on conflict(app_id) do update set downloads=public.app_stats.downloads+1,updated_at=now(),last_downloaded_at=now()
  returning * into r;
  return r;
end; $$;

grant execute on function public.increment_app_view(text) to anon, authenticated;
grant execute on function public.increment_app_download(text) to anon, authenticated;

-- -----------------------------
-- VISITOR HARI INI
-- -----------------------------
create table if not exists public.daily_visitors (
  visit_date date not null,
  visitor_key text not null,
  created_at timestamptz not null default now(),
  primary key(visit_date,visitor_key)
);
alter table public.daily_visitors enable row level security;

create or replace function public.register_daily_visitor(p_visit_date date,p_visitor_key text)
returns bigint
language plpgsql security definer set search_path=public
as $$
declare total bigint;
begin
  insert into public.daily_visitors(visit_date,visitor_key)
  values(p_visit_date,p_visitor_key)
  on conflict(visit_date,visitor_key) do nothing;
  select count(*) into total from public.daily_visitors where visit_date=p_visit_date;
  return total;
end; $$;
grant execute on function public.register_daily_visitor(date,text) to anon, authenticated;

-- -----------------------------
-- CHAT ONLINE 24 JAM
-- -----------------------------
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  sender_name varchar(24) not null,
  sender_key text not null,
  message_type text not null default 'text' check(message_type in ('text','image')),
  message_text text,
  image_data text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint chat_content_valid check (
    (message_type='text' and message_text is not null and char_length(message_text) between 1 and 1000 and image_data is null)
    or
    (message_type='image' and image_data is not null and octet_length(image_data) <= 2000000 and message_text is null)
  )
);

create index if not exists chat_messages_created_at_idx on public.chat_messages(created_at);

alter table public.chat_messages enable row level security;

drop policy if exists "public read active chat" on public.chat_messages;
create policy "public read active chat"
on public.chat_messages for select to anon, authenticated
using(created_at > now() - interval '24 hours');

drop policy if exists "public insert chat" on public.chat_messages;
create policy "public insert chat"
on public.chat_messages for insert to anon, authenticated
with check(
  char_length(sender_name) between 2 and 24
  and char_length(sender_key) between 8 and 120
  and created_at > now() - interval '5 minutes'
);

grant select,insert on public.chat_messages to anon, authenticated;
revoke update,delete on public.chat_messages from anon, authenticated;

create or replace function public.update_chat_message(p_id uuid,p_sender_key text,p_text text)
returns boolean
language plpgsql security definer set search_path=public
as $$
begin
  update public.chat_messages
  set message_text=left(trim(p_text),1000),updated_at=now()
  where id=p_id and sender_key=p_sender_key and message_type='text'
    and created_at > now()-interval '24 hours';
  return found;
end; $$;

create or replace function public.delete_chat_message(p_id uuid,p_sender_key text)
returns boolean
language plpgsql security definer set search_path=public
as $$
begin
  delete from public.chat_messages where id=p_id and sender_key=p_sender_key;
  return found;
end; $$;

create or replace function public.cleanup_expired_chat_messages()
returns integer
language plpgsql security definer set search_path=public
as $$
declare n integer;
begin
  delete from public.chat_messages where created_at <= now()-interval '24 hours';
  get diagnostics n = row_count;
  return n;
end; $$;

grant execute on function public.update_chat_message(uuid,text,text) to anon, authenticated;
grant execute on function public.delete_chat_message(uuid,text) to anon, authenticated;
grant execute on function public.cleanup_expired_chat_messages() to anon, authenticated;

-- Aktifkan realtime untuk chat (aman jika sudah pernah ditambahkan)
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='chat_messages'
  ) then
    alter publication supabase_realtime add table public.chat_messages;
  end if;
end $$;
