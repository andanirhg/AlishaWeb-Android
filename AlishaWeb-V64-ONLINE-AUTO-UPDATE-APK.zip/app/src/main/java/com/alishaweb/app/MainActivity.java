package com.alishaweb.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String HOME_URL = "https://www.alishaweb.com/";

    private FrameLayout safeRoot;
    private WebView webView;
    private WebView externalWebView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        safeRoot = findViewById(R.id.safe_root);
        webView = findViewById(R.id.webview);

        safeRoot.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int topInset;
                int bottomInset;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                    topInset = bars.top;
                    bottomInset = bars.bottom;
                } else {
                    topInset = insets.getSystemWindowInsetTop();
                    bottomInset = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(0, topInset, 0, bottomInset);
                return insets;
            }
        });
        safeRoot.requestApplyInsets();

        configureMainWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    private void applyCommonSettings(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
    }

    private void configureMainWebView() {
        applyCommonSettings(webView);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                return openFileChooser(callback, params);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          android.os.Message resultMsg) {
                final WebView popupCatcher = new WebView(MainActivity.this);
                applyCommonSettings(popupCatcher);
                popupCatcher.setWebViewClient(new WebViewClient() {
                    private boolean handled = false;
                    private boolean capture(String url) {
                        if (handled || url == null || url.trim().isEmpty()) return true;
                        handled = true;
                        openUrlFromMain(url);
                        popupCatcher.stopLoading();
                        popupCatcher.destroy();
                        return true;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        return capture(request.getUrl().toString());
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, String url) {
                        return capture(url);
                    }
                });

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupCatcher);
                resultMsg.sendToTarget();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            private boolean handleMainNavigation(String url) {
                if (url == null || url.trim().isEmpty()) return false;
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                    if ("http".equals(scheme) || "https".equals(scheme)) {
                        if (isAlishaWebHost(uri)) return false;
                        return openUrlFromMain(url);
                    }
                    if ("file".equals(scheme)) return false;
                } catch (Exception ignored) {}
                return openUrlFromMain(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleMainNavigation(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleMainNavigation(url);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) ->
                openOutsideApp(url));
    }

    /*
     * V27: halaman web APK TIDAK lagi mengganti WebView utama dan TIDAK lagi
     * membuka browser Activity di atas AlishaWeb. Halaman tersebut dibuka pada
     * WebView kedua (overlay) di Activity yang sama. Karena WebView utama tetap
     * hidup di bawahnya, tombol Back hanya menutup overlay dan posisi halaman,
     * popup, filter, dan scroll AlishaWeb tidak dimuat ulang.
     */
    private boolean isAlishaWebHost(Uri uri) {
        if (uri == null) return false;
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        return host.equals("alishaweb.com") || host.equals("www.alishaweb.com");
    }

    private boolean openUrlFromMain(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Exception e) {
            return false;
        }

        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if ("http".equals(scheme) || "https".equals(scheme)) {
            if (isAlishaWebHost(uri)) {
                webView.loadUrl(url);
                return true;
            }
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (host.equals("wa.me") || host.endsWith("whatsapp.com") ||
                host.equals("t.me") || host.endsWith("telegram.me")) {
                openOutsideApp(url);
            } else {
                openExternalOverlay(url);
            }
            return true;
        }

        if ("whatsapp".equals(scheme) || "tg".equals(scheme) ||
            "intent".equals(scheme) || "market".equals(scheme)) {
            openOutsideApp(url);
            return true;
        }

        return false;
    }

    private void openExternalOverlay(String url) {
        closeExternalOverlay();

        externalWebView = new WebView(this);
        externalWebView.setBackgroundColor(0xFF001B12);
        applyCommonSettings(externalWebView);

        externalWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                return openFileChooser(callback, params);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          android.os.Message resultMsg) {
                WebView child = new WebView(MainActivity.this);
                applyCommonSettings(child);
                child.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        String u = request.getUrl().toString();
                        openExternalOverlay(u);
                        child.destroy();
                        return true;
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, String u) {
                        openExternalOverlay(u);
                        child.destroy();
                        return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(child);
                resultMsg.sendToTarget();
                return true;
            }
        });

        externalWebView.setWebViewClient(new WebViewClient() {
            private boolean handle(Uri uri) {
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                openOutsideApp(uri.toString());
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handle(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try { return handle(Uri.parse(url)); } catch (Exception e) { return false; }
            }
        });

        externalWebView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimetype, contentLength) ->
                openOutsideApp(downloadUrl));

        safeRoot.addView(externalWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        externalWebView.loadUrl(url);
    }

    private void closeExternalOverlay() {
        if (externalWebView == null) return;
        try {
            externalWebView.stopLoading();
            externalWebView.loadUrl("about:blank");
            externalWebView.clearHistory();
            safeRoot.removeView(externalWebView);
            externalWebView.removeAllViews();
            externalWebView.destroy();
        } catch (Exception ignored) {}
        externalWebView = null;
    }

    private boolean openFileChooser(ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        filePathCallback = callback;

        Intent intent;
        try {
            intent = params.createIntent();
        } catch (Exception e) {
            intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
        }
        if (intent.getType() == null || "*/*".equals(intent.getType())) intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});

        try {
            startActivityForResult(intent, FILE_CHOOSER_REQUEST);
            return true;
        } catch (Exception e) {
            filePathCallback = null;
            return false;
        }
    }

    private void openOutsideApp(String url) {
        if (url == null || url.trim().isEmpty()) return;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();

        try {
            if ("whatsapp".equals(scheme) || "https".equals(scheme) &&
                    ("wa.me".equalsIgnoreCase(uri.getHost()) ||
                     (uri.getHost() != null && uri.getHost().toLowerCase().endsWith("whatsapp.com")))) {
                Intent wa = new Intent(Intent.ACTION_VIEW, uri);
                wa.setPackage("com.whatsapp");
                try { startActivity(wa); return; }
                catch (ActivityNotFoundException ignored) {
                    wa.setPackage("com.whatsapp.w4b");
                    try { startActivity(wa); return; } catch (Exception ignored2) {}
                }
            }

            if ("tg".equals(scheme) || "https".equals(scheme) &&
                    ("t.me".equalsIgnoreCase(uri.getHost()) ||
                     (uri.getHost() != null && uri.getHost().toLowerCase().endsWith("telegram.me")))) {
                Intent tg = new Intent(Intent.ACTION_VIEW, uri);
                tg.setPackage("org.telegram.messenger");
                try { startActivity(tg); return; } catch (Exception ignored) {}
            }

            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {}
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if ((results == null || results.length == 0) && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    private void closeAppImmediately() {
        closeExternalOverlay();
        if (webView != null) {
            webView.setVisibility(View.INVISIBLE);
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        finishAndRemoveTask();
        overridePendingTransition(0, 0);
    }

    @Override
    public void onBackPressed() {
        if (externalWebView != null) {
            if (externalWebView.canGoBack()) {
                externalWebView.goBack();
            } else {
                closeExternalOverlay();
            }
            return;
        }

        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            closeAppImmediately();
        }
    }

    @Override
    protected void onDestroy() {
        closeExternalOverlay();
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
