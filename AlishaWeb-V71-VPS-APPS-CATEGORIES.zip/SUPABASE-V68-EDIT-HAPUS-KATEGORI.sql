-- AlishaWeb V68 - jalankan SEKALI setelah V67.
-- Menambah fungsi aman untuk EDIT / HAPUS kategori dari Panel Admin.

create or replace function public.admin_rename_category(p_id bigint, p_new_name text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  old_name text;
  clean_name text;
begin
  if not public.is_admin() then
    raise exception 'Akses ditolak';
  end if;

  clean_name := upper(trim(regexp_replace(coalesce(p_new_name,''), '\\s+', ' ', 'g')));
  if clean_name = '' then
    raise exception 'Nama kategori tidak boleh kosong';
  end if;

  select name into old_name from public.categories where id = p_id;
  if old_name is null then
    raise exception 'Kategori tidak ditemukan';
  end if;

  if exists(select 1 from public.categories where upper(name)=clean_name and id<>p_id) then
    raise exception 'Kategori sudah ada';
  end if;

  update public.apps set category = clean_name where upper(category)=upper(old_name);
  update public.categories set name = clean_name where id = p_id;
end;
$$;

grant execute on function public.admin_rename_category(bigint,text) to authenticated;

create or replace function public.admin_delete_category(p_id bigint)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  old_name text;
  used_count integer;
begin
  if not public.is_admin() then
    raise exception 'Akses ditolak';
  end if;

  select name into old_name from public.categories where id = p_id;
  if old_name is null then
    raise exception 'Kategori tidak ditemukan';
  end if;

  select count(*) into used_count from public.apps where upper(category)=upper(old_name);
  if used_count > 0 then
    raise exception 'Kategori masih dipakai % APK. Pindahkan APK terlebih dahulu.', used_count;
  end if;

  delete from public.categories where id = p_id;
end;
$$;

grant execute on function public.admin_delete_category(bigint) to authenticated;
