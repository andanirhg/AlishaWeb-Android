-- AlishaWeb V69 - jalankan SEKALI setelah V68.
-- Menambah tombol NAIK / TURUN kategori tanpa mengetik nomor urutan.

create or replace function public.admin_move_category(p_id bigint, p_direction text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  current_order integer;
  other_id bigint;
  other_order integer;
begin
  if not public.is_admin() then
    raise exception 'Akses ditolak';
  end if;

  if lower(coalesce(p_direction,'')) not in ('up','down') then
    raise exception 'Arah tidak valid';
  end if;

  select sort_order into current_order
  from public.categories
  where id = p_id and active = true;

  if current_order is null then
    raise exception 'Kategori tidak ditemukan';
  end if;

  if lower(p_direction) = 'up' then
    select id, sort_order into other_id, other_order
    from public.categories
    where active = true and (sort_order < current_order or (sort_order = current_order and id < p_id))
    order by sort_order desc, id desc
    limit 1;
  else
    select id, sort_order into other_id, other_order
    from public.categories
    where active = true and (sort_order > current_order or (sort_order = current_order and id > p_id))
    order by sort_order asc, id asc
    limit 1;
  end if;

  if other_id is null then
    return;
  end if;

  -- Tukar posisi secara aman. Nilai sementara mencegah bentrok jika nanti ada unique constraint.
  update public.categories set sort_order = -2147483648 where id = p_id;
  update public.categories set sort_order = current_order where id = other_id;
  update public.categories set sort_order = other_order where id = p_id;
end;
$$;

grant execute on function public.admin_move_category(bigint,text) to authenticated;
